Task:
Bootstrap rows and cols