
    document.getElementById('footer').innerText = new Date().getFullYear();
